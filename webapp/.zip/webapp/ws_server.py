# ws_server.py
import asyncio
import websockets
import datetime

connected_clients = set()

async def handler(websocket, path):
    connected_clients.add(websocket)
    print("added")
    try:
        while True:
            # Send timestamp every 5 seconds
            timestamp = datetime.datetime.now().timestamp()
            for client in connected_clients:
                await client.send(str(timestamp))
                # print(f"sent {timestamp}")
            await asyncio.sleep(.1)
    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        connected_clients.remove(websocket)
        print("removed")

start_server = websockets.serve(handler, "0.0.0.0", 8765)  # Listen on all interfaces

asyncio.get_event_loop().run_until_complete(start_server)
print("WebSocket server running on ws://127.0.0.1:8765")
asyncio.get_event_loop().run_forever()
